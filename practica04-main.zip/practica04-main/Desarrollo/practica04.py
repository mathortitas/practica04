#Verificar si hay R en las letras del color

listacolors = [ "rojo" , "marron" , "verde" , "azul" , "amarillo" , "blanco" , "negro"]
listaR= []

for x in listacolors:
    if "r" in x:
        listaR.append(x)
#imprimir del 1 al 10
for i in range(1,11,1):
    print(i)

#imprimir n° en la pos 9
for i in lista:
    if i == 8:
        print(i)
    else:
        continue